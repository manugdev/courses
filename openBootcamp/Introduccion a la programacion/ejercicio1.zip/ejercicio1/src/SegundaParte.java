public class SegundaParte {
    public static void main(String[] args) {
        Coche miCoche = new Coche();
        miCoche.IncrementoPuertas();
        System.out.println(miCoche.puertas);
    }
}
class Coche{
    public int puertas = 0;

    public void IncrementoPuertas(){
        this.puertas++;
    }
}
