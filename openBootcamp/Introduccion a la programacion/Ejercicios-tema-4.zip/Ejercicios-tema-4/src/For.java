public class For {
    public static void main(String[] args){
        int numeroFor = 0;
        for(; numeroFor <= 3; numeroFor++) {
            System.out.println(numeroFor);
        }
    }
}
