public class DoWhile {
    public static void main(String[] args){
        int numeroWhile = 0;
        do{
            System.out.println(numeroWhile);
            numeroWhile ++;
        } while(numeroWhile < 3);
    }
}
