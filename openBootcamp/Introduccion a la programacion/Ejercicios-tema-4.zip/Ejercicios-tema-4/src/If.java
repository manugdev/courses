public class If {
    public static void main(String[] args){
        int numeroIf = 0;
        if(numeroIf == 0){
            System.out.println("El numero es 0");
        } else if(numeroIf > 0){
            System.out.println("El numero es positivo");
        } else {
            System.out.println("El numero es negativo");
        }
    }
}
