public class Main {
    public static void main(String[] args){
        Cliente cliente1 = new Cliente();
        cliente1.setEdad(26);
        cliente1.setTelefono(1126789045);
        cliente1.setNombre("Manuel");
        cliente1.setCredito(20000);
        System.out.println(cliente1.getEdad());
        System.out.println(cliente1.getTelefono());
        System.out.println(cliente1.getNombre());
        System.out.println(cliente1.getCredito());

        Trabajador trabajador1 = new Trabajador();
        trabajador1.setEdad(30);
        trabajador1.setTelefono(1112312312);
        trabajador1.setNombre("Lucia");
        trabajador1.setSalario(140000);
        System.out.println(trabajador1.getEdad());
        System.out.println(trabajador1.getTelefono());
        System.out.println(trabajador1.getNombre());
        System.out.println(trabajador1.getSalario());
    }
}

class Persona{
    private int edad;
    private String nombre;
    private int telefono;

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
}

class Cliente extends Persona{
    private int credito;

    public int getCredito() {
        return credito;
    }

    public void setCredito(int credito) {
        this.credito = credito;
    }
}

class Trabajador extends Persona{
    private int salario;

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }
}